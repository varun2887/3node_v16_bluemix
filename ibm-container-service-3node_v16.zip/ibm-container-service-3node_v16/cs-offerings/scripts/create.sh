#!/bin/bash

if [ "${PWD##*/}" == "create" ]; then
	:
elif [ "${PWD##*/}" == "scripts" ]; then
	:
else
    echo "Please run the script from 'scripts' or 'scripts/create' folder"
fi

echo ""
echo "=> CREATE_ALL: Creating storage"
create/create_storage.sh $@


echo ""
echo "=> CREATE_ALL: Creating blockchain"
create/create_blockchain.sh $@

echo ""
echo "=> CREATE_ALL: Running Create Channel"
#PEER_MSPID="Org1MSP" CHANNEL_NAME="channel1" create/create_channel.sh

#connection-profile/generate-connection-profile.sh -o org3 -c Blockchain.IL.TRS.Paid.01
